<?php

/**
 * @file
 * Generic transliteration data for the PhpTransliteration class.
 */

$base = [
  0x00 => 'huai', 'tai', 'song', 'wu', 'ou', 'chang', 'chuang', 'ju', 'yi', 'bao', 'chao', 'min', 'pei', 'zuo', 'zen', 'yang',
  0x10 => 'ju', 'ban', 'nu', 'nao', 'zheng', 'pa', 'bu', 'tie', 'hu', 'hu', 'ju', 'da', 'lian', 'si', 'chou', 'di',
  0x20 => 'dai', 'yi', 'tu', 'you', 'fu', 'ji', 'peng', 'xing', 'yuan', 'ni', 'guai', 'fu', 'xi', 'bi', 'you', 'qie',
  0x30 => 'xuan', 'cong', 'bing', 'huang', 'xu', 'chu', 'bi', 'shu', 'xi', 'tan', 'yong', 'zong', 'dui', 'mo', 'zhi', 'yi',
  0x40 => 'shi', 'nen', 'xun', 'shi', 'xi', 'lao', 'heng', 'kuang', 'mou', 'zhi', 'xie', 'lian', 'tiao', 'huang', 'die', 'hao',
  0x50 => 'kong', 'gui', 'heng', 'xi', 'jiao', 'shu', 'si', 'hu', 'qiu', 'yang', 'hui', 'hui', 'chi', 'jia', 'yi', 'xiong',
  0x60 => 'guai', 'lin', 'hui', 'zi', 'xu', 'chi', 'shang', 'nu', 'hen', 'en', 'ke', 'dong', 'tian', 'gong', 'quan', 'xi',
  0x70 => 'qia', 'yue', 'peng', 'ken', 'de', 'hui', 'e', 'xiao', 'tong', 'yan', 'kai', 'ce', 'nao', 'yun', 'mang', 'yong',
  0x80 => 'yong', 'yuan', 'pi', 'kun', 'qiao', 'yue', 'yu', 'tu', 'jie', 'xi', 'zhe', 'lin', 'ti', 'han', 'hao', 'qie',
  0x90 => 'ti', 'bu', 'yi', 'qian', 'hui', 'xi', 'bei', 'man', 'yi', 'heng', 'song', 'quan', 'cheng', 'kui', 'wu', 'wu',
  0xA0 => 'you', 'li', 'liang', 'huan', 'cong', 'yi', 'yue', 'li', 'nin', 'nao', 'e', 'que', 'xuan', 'qian', 'wu', 'min',
  0xB0 => 'cong', 'fei', 'bei', 'duo', 'cui', 'chang', 'men', 'san', 'ji', 'guan', 'guan', 'xing', 'dao', 'qi', 'kong', 'tian',
  0xC0 => 'lun', 'xi', 'kan', 'gun', 'ni', 'qing', 'chou', 'dun', 'guo', 'zhan', 'jing', 'wan', 'yuan', 'jin', 'ji', 'lan',
  0xD0 => 'yu', 'huo', 'he', 'quan', 'tan', 'ti', 'ti', 'nie', 'wang', 'chuo', 'hu', 'hun', 'xi', 'chang', 'xin', 'wei',
  0xE0 => 'hui', 'e', 'suo', 'zong', 'jian', 'yong', 'dian', 'ju', 'can', 'cheng', 'de', 'bei', 'qie', 'can', 'dan', 'guan',
  0xF0 => 'duo', 'nao', 'yun', 'xiang', 'zhui', 'die', 'huang', 'chun', 'qiong', 're', 'xing', 'ce', 'bian', 'min', 'zong', 'ti',
];
